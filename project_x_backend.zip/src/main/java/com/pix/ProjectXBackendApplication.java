package com.pix;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectXBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectXBackendApplication.class, args);
	}

}
